%example to show how to use plot_stl
triangles = read_binary_stl_file('D6641_part.stl');
plot_stl(triangles);